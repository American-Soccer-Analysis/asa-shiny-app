
cat("stdout\n")
message("stderr")
