

$( document ).ready(function() {
  $('kbd').children().unwrap();
});


