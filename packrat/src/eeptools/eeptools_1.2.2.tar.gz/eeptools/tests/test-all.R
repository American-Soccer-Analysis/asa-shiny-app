library(testthat)
library(eeptools)

test_check("eeptools")
